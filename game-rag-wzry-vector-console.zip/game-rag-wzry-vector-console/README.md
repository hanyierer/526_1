# 王者荣耀知识库 RAG 项目：只保留两种向量检索 + 控制台模式

本项目基于 Java 17 + Spring Boot + Maven，实现王者荣耀知识库在线 RAG 检索。

当前版本已经按你的 Milvus schema 修改：

```text
id
title
chunk_id
content
content_dense_vector
content_sparse_vector
doc_id
```

并且已经**删除关键字检索**，只保留两路向量检索：

```text
1. Dense Vector 检索：BGE-M3 生成 query dense vector，检索 content_dense_vector
2. Sparse Vector 检索：Milvus BM25 Function 自动处理 query，检索 content_sparse_vector
```

---

## 1. 本次关键修改

### 1.1 删除关键字检索

删除/不再使用原来的：

```text
keyword-query-enabled
keyword-top-k
keyword-filter-template
KEYWORD_QUERY
keywordQuery()
TEXT_MATCH(...)
```

现在 `MilvusRetrievalService` 只有：

```java
private List<SearchHit> denseSearch(String query, String filter)
private List<SearchHit> sparseSearch(String query, String filter)
```

`RecallChannel` 只剩：

```java
DENSE_VECTOR
SPARSE_VECTOR
```

### 1.2 Milvus 字段映射改成你的 collection

在 `application.yml` 中改为：

```yaml
rag:
  milvus:
    collection: wzry_knowledge
    primary-key-field: id
    text-field: content
    title-field: title
    dense-vector-field: content_dense_vector
    sparse-vector-field: content_sparse_vector
    output-fields:
      - id
      - title
      - chunk_id
      - content
      - doc_id
```

### 1.3 删除 gameId 过滤

`RagQueryRequest` 已删除 `gameId` 字段。

请求中不要再传：

```json
{"gameId":"xxx"}
```

如需过滤，使用：

```json
{
  "filters": {
    "doc_id": "D001"
  }
}
```

### 1.4 增加控制台模式

新增：

```text
src/main/java/com/example/gamerag/runner/ConsoleRagRunner.java
src/main/resources/application-console.yml
```

控制台启动后可直接输入问题，例如：

```text
孙权的被动技能是什么？
```

---

## 2. 项目结构

```text
game-rag-wzry-vector-console/
├─ pom.xml
├─ README.md
├─ .env.example
├─ data/
│  └─ wzry_milvus_mock_50.csv
├─ docs/
│  └─ api.http
└─ src/main/
   ├─ resources/
   │  ├─ application.yml
   │  └─ application-console.yml
   └─ java/com/example/gamerag/
      ├─ GameRagOnlineApplication.java
      ├─ config/
      ├─ controller/
      ├─ dto/
      ├─ exception/
      ├─ model/
      ├─ runner/
      │  └─ ConsoleRagRunner.java
      ├─ service/
      │  ├─ BgeEmbeddingClient.java
      │  ├─ BgeRerankerClient.java
      │  ├─ DoubaoClient.java
      │  ├─ MilvusRetrievalService.java
      │  ├─ QueryUnderstandingService.java
      │  ├─ RagService.java
      │  ├─ RetrievalRouter.java
      │  ├─ RerankService.java
      │  └─ RrfFusionService.java
      ├─ tools/
      │  └─ GenerateWzryBgeM3Vectors.java
      └─ util/
```

---

## 3. 需要准备的外部服务

### 3.1 Milvus

你的 collection 应该包含：

```text
id                      主键
title                   VARCHAR
chunk_id                INT64 或 VARCHAR
content                 VARCHAR，建议启用 analyzer
content_dense_vector    FLOAT_VECTOR，BGE-M3 dense vector，常见维度 1024
content_sparse_vector   SPARSE_FLOAT_VECTOR，由 Milvus BM25 Function 自动生成
doc_id                  VARCHAR
```

### 3.2 BGE-M3 Embedding 服务

要求接口兼容：

```http
POST /v1/embeddings
```

请求体：

```json
{
  "model": "BAAI/bge-m3",
  "input": "孙权的被动技能是什么？"
}
```

### 3.3 bge-reranker-v2-m3 服务

要求接口兼容：

```http
POST /v1/rerank
```

请求体：

```json
{
  "model": "BAAI/bge-reranker-v2-m3",
  "query": "孙权的被动技能是什么？",
  "documents": ["片段1", "片段2"],
  "top_n": 20,
  "return_documents": false
}
```

如果暂时没有 reranker，可以配置：

```yaml
rag:
  reranker:
    enabled: false
```

系统会使用启发式 fallback。

### 3.4 豆包 Chat 服务

用于 Query 理解和最终答案生成。

---

## 4. 配置

配置文件：

```text
src/main/resources/application.yml
```

重点配置：

```yaml
rag:
  doubao:
    api-key: ${DOUBAO_API_KEY:}
    chat-model: ${DOUBAO_CHAT_MODEL:ep-your-doubao-chat-endpoint}

  embedding:
    base-url: ${BGE_BASE_URL:http://127.0.0.1:9997/v1}
    model: ${BGE_EMBEDDING_MODEL:BAAI/bge-m3}
    require-api-key: ${BGE_REQUIRE_API_KEY:false}

  reranker:
    enabled: ${BGE_RERANK_ENABLED:true}
    base-url: ${BGE_RERANK_BASE_URL:${BGE_BASE_URL:http://127.0.0.1:9997/v1}}
    model: ${BGE_RERANK_MODEL:BAAI/bge-reranker-v2-m3}
    require-api-key: ${BGE_RERANK_REQUIRE_API_KEY:false}

  milvus:
    endpoint: ${MILVUS_ENDPOINT:http://localhost:19530}
    token: ${MILVUS_TOKEN:root:Milvus}
    collection: ${MILVUS_COLLECTION:wzry_knowledge}
    dense-vector-field: ${MILVUS_DENSE_FIELD:content_dense_vector}
    sparse-vector-field: ${MILVUS_SPARSE_FIELD:content_sparse_vector}
    dense-search-enabled: true
    sparse-search-enabled: true
```

---

## 5. 生成模拟数据 dense vector

项目内已包含：

```text
src/main/java/com/example/gamerag/tools/GenerateWzryBgeM3Vectors.java
```

它会读取：

```text
data/wzry_milvus_mock_50.csv
```

然后调用 BGE-M3 embedding 接口，生成：

```text
data/wzry_milvus_mock_50_with_vectors.csv
```

运行：

```bash
mvn exec:java -Dexec.mainClass="com.example.gamerag.tools.GenerateWzryBgeM3Vectors"
```

注意：`content_sparse_vector` 不需要在 CSV 中手动生成，由 Milvus BM25 Function 自动生成。

---

## 6. 控制台模式运行

Windows CMD：

```bat
chcp 65001
mvn clean package -DskipTests
java -Dfile.encoding=UTF-8 -jar target/game-rag-online-1.0.0.jar --spring.profiles.active=console
```

PowerShell：

```powershell
$env:JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8"
mvn clean package -DskipTests
java -jar target/game-rag-online-1.0.0.jar --spring.profiles.active=console
```

启动后输入：

```text
孙权的被动技能是什么？
```

控制台命令：

```text
:config        查看配置
:topk 6        设置返回片段数量
:debug on      开启 debug
:debug off     关闭 debug
:clear         清空缓存
exit           退出
```

---

## 7. Web 接口模式运行

```bash
mvn spring-boot:run
```

健康检查：

```bash
curl http://localhost:8080/api/rag/health
```

问答接口：

```bash
curl -X POST http://localhost:8080/api/rag/query \
  -H "Content-Type: application/json" \
  -d '{
    "query": "孙权的被动技能是什么？",
    "topK": 6,
    "debug": true
  }'
```

带 doc_id 过滤：

```bash
curl -X POST http://localhost:8080/api/rag/query \
  -H "Content-Type: application/json" \
  -d '{
    "query": "孙权的技能介绍",
    "topK": 6,
    "debug": true,
    "filters": {
      "doc_id": "D001"
    }
  }'
```

---

## 8. 分阶段测试建议

第一步只测 dense：

```yaml
rag:
  reranker:
    enabled: false
  query-understanding:
    enabled: false
  milvus:
    dense-search-enabled: true
    sparse-search-enabled: false
```

跑通后再打开 sparse：

```yaml
rag:
  milvus:
    sparse-search-enabled: true
```

最后打开 rerank 和 Query 理解：

```yaml
rag:
  reranker:
    enabled: true
  query-understanding:
    enabled: true
```

---

## 9. 常见问题

### 9.1 sparse search 报 searchParams 或 metric_type 错误

把：

```yaml
rag:
  milvus:
    sparse-use-bm25-search-params: false
```

如果你的 Milvus REST 服务要求显式 BM25，再改成 true。

### 9.2 Milvus 字段不存在

检查：

```yaml
output-fields:
  - id
  - title
  - chunk_id
  - content
  - doc_id
```

不要写不存在的 `source/url/game_id/doc_type/version`。

### 9.3 vector dimension mismatch

说明离线 `content_dense_vector` 不是用线上 BGE-M3 同一模型生成的，或者维度不一致。

---

## 10. 本版本不包含关键字检索

不再使用：

```text
TEXT_MATCH
keywordQuery
keyword-query-enabled
keyword-filter-template
keyword-top-k
```

最终检索链路是：

```text
Query
  -> Query理解/改写
  -> BGE-M3 dense query vector
  -> Milvus content_dense_vector 检索
  -> Milvus content_sparse_vector 稀疏向量检索
  -> RRF 融合去重
  -> bge-reranker-v2-m3 精排
  -> 豆包生成答案
```
