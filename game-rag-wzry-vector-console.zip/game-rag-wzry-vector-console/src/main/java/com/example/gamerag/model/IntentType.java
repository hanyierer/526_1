package com.example.gamerag.model;

public enum IntentType {
    HERO_SKILL,
    HERO_BUILD,
    LANING,
    TEAM_FIGHT,
    COUNTER_PICK,
    ITEM_QUERY,
    GAME_MECHANIC,
    GENERAL_QA
}
