package com.example.gamerag.runner;

import com.example.gamerag.config.RagProperties;
import com.example.gamerag.dto.RagQueryRequest;
import com.example.gamerag.dto.RagQueryResponse;
import com.example.gamerag.dto.ReferenceDto;
import com.example.gamerag.service.RagCacheService;
import com.example.gamerag.service.RagService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

@Component
@ConditionalOnProperty(prefix = "rag.console", name = "enabled", havingValue = "true")
public class ConsoleRagRunner implements CommandLineRunner {
    private final RagService ragService;
    private final RagCacheService cacheService;
    private final RagProperties properties;
    private Integer topK;
    private Boolean debug;

    public ConsoleRagRunner(RagService ragService, RagCacheService cacheService, RagProperties properties) {
        this.ragService = ragService;
        this.cacheService = cacheService;
        this.properties = properties;
        this.topK = properties.getConsole().getTopK();
        this.debug = properties.getConsole().getDebug();
    }

    @Override
    public void run(String... args) {
        printWelcome();
        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8.name());
        while (true) {
            System.out.print("\nRAG> ");
            if (!scanner.hasNextLine()) break;
            String input = scanner.nextLine().trim();
            if (input.isBlank()) continue;
            if (isExit(input)) {
                System.out.println("已退出控制台 RAG。");
                break;
            }
            if (handleCommand(input)) continue;
            ask(input);
        }
    }

    private void ask(String query) {
        try {
            RagQueryRequest request = new RagQueryRequest();
            request.setQuery(query);
            request.setTopK(topK);
            request.setDebug(debug);
            request.setBypassCache(false);
            RagQueryResponse response = ragService.query(request);
            printAnswer(response);
            printReferences(response);
            if (Boolean.TRUE.equals(debug)) printDebug(response);
        } catch (Exception e) {
            System.out.println("\n[ERROR] 调用失败：" + e.getMessage());
            e.printStackTrace(System.out);
        }
    }

    private boolean handleCommand(String input) {
        if (input.equalsIgnoreCase(":help")) {
            printHelp();
            return true;
        }
        if (input.equalsIgnoreCase(":config")) {
            printConfig();
            return true;
        }
        if (input.equalsIgnoreCase(":clear")) {
            cacheService.clear();
            System.out.println("已清空 RAG 缓存。");
            return true;
        }
        if (input.startsWith(":topk ")) {
            String value = input.substring(":topk ".length()).trim();
            try {
                int parsed = Integer.parseInt(value);
                if (parsed <= 0 || parsed > 20) System.out.println("topK 建议设置为 1 到 20");
                else {
                    this.topK = parsed;
                    System.out.println("已设置 topK = " + this.topK);
                }
            } catch (NumberFormatException e) {
                System.out.println("topK 必须是整数，例如：:topk 6");
            }
            return true;
        }
        if (input.equalsIgnoreCase(":debug on")) {
            this.debug = true;
            System.out.println("已开启 debug");
            return true;
        }
        if (input.equalsIgnoreCase(":debug off")) {
            this.debug = false;
            System.out.println("已关闭 debug");
            return true;
        }
        return false;
    }

    private void printAnswer(RagQueryResponse response) {
        System.out.println("\n==================== 回答 ====================");
        System.out.println(nullToEmpty(response.getAnswer()));
        System.out.println("\n缓存命中：" + response.isCacheHit());
    }

    private void printReferences(RagQueryResponse response) {
        System.out.println("\n==================== 引用片段 ====================");
        if (response.getReferences() == null || response.getReferences().isEmpty()) {
            System.out.println("无引用片段");
            return;
        }
        for (ReferenceDto ref : response.getReferences()) {
            System.out.println("[" + ref.getIndex() + "] " + nullToEmpty(ref.getTitle()));
            System.out.println("ID: " + nullToEmpty(ref.getId()));
            System.out.println("Doc ID: " + nullToEmpty(ref.getDocId()));
            System.out.println("Chunk ID: " + nullToEmpty(ref.getChunkId()));
            System.out.println("Score: " + ref.getScore());
            if (ref.getSnippet() != null && !ref.getSnippet().isBlank()) System.out.println("Snippet: " + ref.getSnippet());
            System.out.println();
        }
    }

    private void printDebug(RagQueryResponse response) {
        System.out.println("\n==================== Debug ====================");
        if (response.getQueryAnalysis() != null) {
            System.out.println("Intent: " + response.getQueryAnalysis().getIntent());
            System.out.println("Strategy: " + response.getQueryAnalysis().getStrategy());
            System.out.println("RewrittenQuery: " + response.getQueryAnalysis().getRewrittenQuery());
            System.out.println("ExpandedQueries: " + response.getQueryAnalysis().getExpandedQueries());
            System.out.println("Keywords: " + response.getQueryAnalysis().getKeywords());
            System.out.println("Entities: " + response.getQueryAnalysis().getEntities());
            System.out.println("Filters: " + response.getQueryAnalysis().getFilters());
        }
        if (response.getDebug() != null && !response.getDebug().isEmpty()) System.out.println("DebugInfo: " + response.getDebug());
    }

    private void printWelcome() {
        System.out.println("==================================================");
        System.out.println("王者荣耀知识库 RAG 控制台模式");
        System.out.println("已删除关键字检索，只保留 dense vector 与 sparse vector 两种向量检索。 ");
        System.out.println("输入问题后回车即可检索和生成答案。");
        System.out.println();
        System.out.println("常用命令：");
        System.out.println("  :help          查看帮助");
        System.out.println("  :config        查看当前配置");
        System.out.println("  :topk 6        设置最终引用片段数量");
        System.out.println("  :debug on      开启 debug 输出");
        System.out.println("  :debug off     关闭 debug 输出");
        System.out.println("  :clear         清空 RAG 缓存");
        System.out.println("  exit / quit    退出");
        System.out.println("==================================================");
        printConfig();
    }

    private void printHelp() {
        System.out.println("\n命令说明：");
        System.out.println("  直接输入问题：例如 孙权的被动技能是什么？");
        System.out.println("  :topk 8            设置返回引用片段数量");
        System.out.println("  :debug on          输出 Query 理解、检索计划、召回数量等信息");
        System.out.println("  :clear             清空缓存");
        System.out.println("  exit               退出程序");
    }

    private void printConfig() {
        Map<String, Object> config = new LinkedHashMap<>();
        config.put("topK", topK);
        config.put("debug", debug);
        config.put("collection", properties.getMilvus().getCollection());
        config.put("denseField", properties.getMilvus().getDenseVectorField());
        config.put("sparseField", properties.getMilvus().getSparseVectorField());
        config.put("keywordRetrieval", "deleted");
        System.out.println("\n当前控制台配置：");
        config.forEach((k, v) -> System.out.println("  " + k + " = " + v));
    }

    private boolean isExit(String input) {
        return "exit".equalsIgnoreCase(input) || "quit".equalsIgnoreCase(input)
                || ":exit".equalsIgnoreCase(input) || ":quit".equalsIgnoreCase(input);
    }

    private String nullToEmpty(String value) { return value == null ? "" : value; }
}
