package com.example.gamerag.model;

public enum RetrievalStrategy {
    DENSE_FIRST,
    SPARSE_FIRST,
    HYBRID_VECTOR
}
