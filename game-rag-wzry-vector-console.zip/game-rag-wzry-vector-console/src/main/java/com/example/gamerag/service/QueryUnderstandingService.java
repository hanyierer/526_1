package com.example.gamerag.service;

import com.example.gamerag.config.RagProperties;
import com.example.gamerag.model.IntentType;
import com.example.gamerag.model.QueryAnalysis;
import com.example.gamerag.model.RetrievalStrategy;
import com.example.gamerag.util.JsonExtractUtils;
import com.example.gamerag.util.TextUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class QueryUnderstandingService {
    private static final Logger log = LoggerFactory.getLogger(QueryUnderstandingService.class);
    private final DoubaoClient doubaoClient;
    private final RagProperties properties;
    private final ObjectMapper objectMapper;

    public QueryUnderstandingService(DoubaoClient doubaoClient, RagProperties properties, ObjectMapper objectMapper) {
        this.doubaoClient = doubaoClient;
        this.properties = properties;
        this.objectMapper = objectMapper;
    }

    public QueryAnalysis analyze(String rawQuery, Map<String, String> requestFilters) {
        if (!properties.getQueryUnderstanding().isEnabled()) return fallback(rawQuery, requestFilters);
        try {
            QueryAnalysis analysis = analyzeByLlm(rawQuery, requestFilters);
            if (analysis.getRewrittenQuery() == null || analysis.getRewrittenQuery().isBlank()) analysis.setRewrittenQuery(rawQuery);
            analysis.setOriginalQuery(rawQuery);
            mergeRequestFilters(analysis, requestFilters);
            analysis.setExpandedQueries(TextUtils.distinctNonBlank(analysis.getExpandedQueries(), properties.getQueryUnderstanding().getMaxExpandedQueries()));
            return analysis;
        } catch (Exception e) {
            log.warn("Query understanding by LLM failed, fallback to rules: {}", e.getMessage());
            if (properties.getQueryUnderstanding().isFallbackToRules()) return fallback(rawQuery, requestFilters);
            throw new IllegalStateException("Query understanding by LLM failed and fallback is disabled", e);
        }
    }

    private QueryAnalysis analyzeByLlm(String rawQuery, Map<String, String> requestFilters) throws Exception {
        String system = "你是王者荣耀知识库 RAG 系统的 Query 理解器，只输出 JSON，不要解释。";
        String user = """
                请分析玩家问题，并输出严格 JSON：
                {
                  "intent": "HERO_SKILL|HERO_BUILD|LANING|TEAM_FIGHT|COUNTER_PICK|ITEM_QUERY|GAME_MECHANIC|GENERAL_QA",
                  "strategy": "DENSE_FIRST|SPARSE_FIRST|HYBRID_VECTOR",
                  "rewrittenQuery": "适合向量检索的完整中文查询",
                  "expandedQueries": ["同义表达或补充检索式，最多4条"],
                  "keywords": ["英雄名、技能名、装备名、玩法关键词"],
                  "entities": {"hero":"", "skill":"", "item":"", "lane":""},
                  "filters": {"doc_id":"可选"}
                }

                注意：系统已经删除关键字检索，只保留 dense vector 与 sparse vector 两路检索。
                因此 strategy 只能用于决定 dense/sparse 两种向量检索权重或开关倾向。

                requestFilters: %s
                rawQuery: %s
                """.formatted(requestFilters, rawQuery);
        String content = doubaoClient.chat(system, user);
        JsonNode json = objectMapper.readTree(JsonExtractUtils.extractFirstJsonObject(content));
        QueryAnalysis analysis = new QueryAnalysis();
        analysis.setIntent(parseEnum(IntentType.class, json.path("intent").asText("GENERAL_QA"), IntentType.GENERAL_QA));
        analysis.setStrategy(parseEnum(RetrievalStrategy.class, json.path("strategy").asText("HYBRID_VECTOR"), RetrievalStrategy.HYBRID_VECTOR));
        analysis.setRewrittenQuery(json.path("rewrittenQuery").asText(rawQuery));
        analysis.setExpandedQueries(readStringList(json.path("expandedQueries")));
        analysis.setKeywords(readStringList(json.path("keywords")));
        analysis.setEntities(readStringMap(json.path("entities")));
        analysis.setFilters(readStringMap(json.path("filters")));
        return analysis;
    }

    private QueryAnalysis fallback(String rawQuery, Map<String, String> requestFilters) {
        QueryAnalysis analysis = new QueryAnalysis();
        analysis.setOriginalQuery(rawQuery);
        analysis.setRewrittenQuery(rawQuery);
        analysis.setExpandedQueries(expandByRules(rawQuery));
        analysis.setKeywords(extractSimpleKeywords(rawQuery));
        analysis.setIntent(ruleIntent(rawQuery));
        analysis.setStrategy(RetrievalStrategy.HYBRID_VECTOR);
        mergeRequestFilters(analysis, requestFilters);
        return analysis;
    }

    private void mergeRequestFilters(QueryAnalysis analysis, Map<String, String> requestFilters) {
        Map<String, String> filters = new LinkedHashMap<>();
        if (analysis.getFilters() != null) filters.putAll(analysis.getFilters());
        if (requestFilters != null) filters.putAll(requestFilters);
        analysis.setFilters(filters);
    }

    private IntentType ruleIntent(String q) {
        String s = q == null ? "" : q.toLowerCase(Locale.ROOT);
        if (s.contains("技能") || s.contains("被动") || s.contains("一技能") || s.contains("大招")) return IntentType.HERO_SKILL;
        if (s.contains("出装") || s.contains("铭文") || s.contains("装备")) return IntentType.HERO_BUILD;
        if (s.contains("对线") || s.contains("清线")) return IntentType.LANING;
        if (s.contains("团战") || s.contains("开团") || s.contains("切后排")) return IntentType.TEAM_FIGHT;
        if (s.contains("克制") || s.contains("打不过") || s.contains("怎么打")) return IntentType.COUNTER_PICK;
        if (s.contains("机制") || s.contains("规则")) return IntentType.GAME_MECHANIC;
        return IntentType.GENERAL_QA;
    }

    private List<String> expandByRules(String rawQuery) {
        List<String> queries = new ArrayList<>();
        if (rawQuery != null && !rawQuery.isBlank()) {
            queries.add(rawQuery);
            if (rawQuery.contains("怎么打")) queries.add(rawQuery.replace("怎么打", "克制方法 对线思路 团战处理"));
            if (rawQuery.contains("出装")) queries.add(rawQuery + " 铭文 召唤师技能 玩法");
            if (rawQuery.contains("技能")) queries.add(rawQuery + " 被动 一技能 二技能 三技能 大招 连招");
        }
        return TextUtils.distinctNonBlank(queries, properties.getQueryUnderstanding().getMaxExpandedQueries());
    }

    private List<String> extractSimpleKeywords(String rawQuery) {
        if (rawQuery == null) return List.of();
        String cleaned = rawQuery.replaceAll("[，。！？；：,.!?;:\\[\\]（）()《》<>]", " ");
        String[] parts = cleaned.split("\\s+");
        List<String> out = new ArrayList<>();
        for (String part : parts) if (part.length() >= 2 && part.length() <= 30) out.add(part);
        if (out.isEmpty() && !rawQuery.isBlank()) out.add(rawQuery.trim());
        return TextUtils.distinctNonBlank(out, 8);
    }

    private List<String> readStringList(JsonNode node) {
        List<String> list = new ArrayList<>();
        if (node != null && node.isArray()) for (JsonNode item : node) if (!item.asText("").isBlank()) list.add(item.asText());
        return list;
    }

    private Map<String, String> readStringMap(JsonNode node) {
        Map<String, String> map = new LinkedHashMap<>();
        if (node != null && node.isObject()) node.fields().forEachRemaining(e -> {
            String value = e.getValue().asText("");
            if (!value.isBlank()) map.put(e.getKey(), value);
        });
        return map;
    }

    private <T extends Enum<T>> T parseEnum(Class<T> type, String value, T fallback) {
        try { return Enum.valueOf(type, value); } catch (Exception e) { return fallback; }
    }
}
