package com.example.gamerag.tools;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * 作用：
 * 1. 读取王者荣耀模拟知识库 CSV。
 * 2. 调用魔搭/ModelScope 来源的 BGE-M3 模型服务生成 content_dense_vector。
 * 3. 输出新的 CSV，content_sparse_vector 仍然留空，后续由 Milvus Function/BM25 自动生成。
 *
 * 使用前提：
 * 1. 你已经把 BAAI/bge-m3 部署成 OpenAI-compatible embedding API。
 *    例如：Xinference / vLLM / LMDeploy / 其他兼容 /v1/embeddings 的服务。
 * 2. 当前 Spring Boot 项目 pom.xml 已经有 Jackson，Spring Boot Web 默认就包含 Jackson。
 *
 * 如果你的服务是本地无鉴权服务：
 *   API_KEY = "";
 *   REQUIRE_API_KEY = false;
 *
 * 如果你的服务需要鉴权：
 *   API_KEY = "sk-xxxx";
 *   REQUIRE_API_KEY = true;
 */
public class GenerateWzryBgeM3Vectors {

    // ===========================
    // 1. 基础配置：按你的环境修改
    // ===========================

    /** 输入 CSV：就是你之前生成的 50 条模拟数据 CSV。 */
    private static final String INPUT_CSV = "D:/Code/game-rag-wzry-vector-console/data/wzry_milvus_mock_50.csv";

    /** 输出 CSV：会在 content_dense_vector 字段写入 BGE-M3 向量 JSON 数组。 */
    private static final String OUTPUT_CSV = "D:/Code/game-rag-wzry-vector-console/data/wzry_milvus_mock_50_with_vectors.csv";

    /**
     * BGE-M3 embedding 服务地址。
     * 情况 A：本地 Xinference/vLLM/OpenAI-compatible 服务，例如 http://127.0.0.1:9997/v1 或 http://127.0.0.1:8000/v1
     * 情况 B：第三方兼容服务，例如 https://api.siliconflow.cn/v1
     */
    private static final String BASE_URL = "http://127.0.0.1:9997/v1";

    /** OpenAI-compatible embedding endpoint，一般不需要改。 */
    private static final String EMBEDDING_PATH = "/embeddings";

    /** 模型名：魔搭社区 / ModelScope 上的 BGE-M3 通常为 BAAI/bge-m3。 */
    private static final String MODEL = "BAAI/bge-m3";

    /** 如果使用第三方 API，填入 API Key；本地无鉴权服务可以留空。 */
    private static final String API_KEY = "";

    /** 本地服务无鉴权时设为 false；第三方 API 一般设为 true。 */
    private static final boolean REQUIRE_API_KEY = false;

    /** 一次请求多少条文本。部分 embedding 服务支持 batch；如果你的服务不支持 batch，把它改成 1。 */
    private static final int BATCH_SIZE = 8;

    /** 请求超时时间。 */
    private static final int TIMEOUT_SECONDS = 120;

    /** 失败后重试次数。 */
    private static final int MAX_RETRY = 3;

    /** 重试间隔毫秒。 */
    private static final long RETRY_SLEEP_MS = 1000L;

    /** CSV 读写编码。之前生成的 CSV 是 UTF-8 with BOM，这里用 UTF-8 读取即可，并会自动去掉 BOM。 */
    private static final Charset CSV_CHARSET = StandardCharsets.UTF_8;

    /** dense vector 字段名。 */
    private static final String DENSE_VECTOR_COLUMN = "content_dense_vector";

    /** sparse vector 字段名。这里保持为空，Milvus 自动生成。 */
    private static final String SPARSE_VECTOR_COLUMN = "content_sparse_vector";

    /** 需要送入 BGE-M3 的文本字段名。 */
    private static final String CONTENT_COLUMN = "content";

    // ===========================
    // 2. 程序入口
    // ===========================

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(TIMEOUT_SECONDS))
            .build();

    public static void main(String[] args) throws Exception {
        GenerateWzryBgeM3Vectors app = new GenerateWzryBgeM3Vectors();
        app.run();
    }

    private void run() throws Exception {
        checkConfig();

        Path input = Path.of(INPUT_CSV);
        Path output = Path.of(OUTPUT_CSV);

        if (!Files.exists(input)) {
            throw new IllegalArgumentException("输入 CSV 不存在: " + input.toAbsolutePath());
        }
        if (output.getParent() != null) {
            Files.createDirectories(output.getParent());
        }

        CsvTable table = readCsv(input);
        checkRequiredColumns(table);

        int contentIndex = table.headerIndex(CONTENT_COLUMN);
        int denseIndex = table.headerIndex(DENSE_VECTOR_COLUMN);
        int sparseIndex = table.headerIndex(SPARSE_VECTOR_COLUMN);

        List<Integer> rowIndexesToEmbed = new ArrayList<>();
        List<String> textsToEmbed = new ArrayList<>();

        for (int i = 0; i < table.rows.size(); i++) {
            List<String> row = table.rows.get(i);
            String content = row.get(contentIndex);
            String existingVector = row.get(denseIndex);

            if (content == null || content.isBlank()) {
                System.out.println("[SKIP] 第 " + (i + 2) + " 行 content 为空");
                continue;
            }

            // 如果已经有 dense vector，跳过，方便断点续跑。
            if (existingVector != null && !existingVector.isBlank()) {
                System.out.println("[SKIP] 第 " + (i + 2) + " 行已有 dense vector");
                continue;
            }

            rowIndexesToEmbed.add(i);
            textsToEmbed.add(content);
        }

        System.out.println("输入文件: " + input.toAbsolutePath());
        System.out.println("输出文件: " + output.toAbsolutePath());
        System.out.println("总行数: " + table.rows.size());
        System.out.println("待生成向量行数: " + textsToEmbed.size());
        System.out.println("模型: " + MODEL);
        System.out.println("接口: " + endpoint());
        System.out.println("Batch size: " + BATCH_SIZE);

        for (int start = 0; start < textsToEmbed.size(); start += BATCH_SIZE) {
            int end = Math.min(start + BATCH_SIZE, textsToEmbed.size());
            List<String> batchTexts = textsToEmbed.subList(start, end);
            List<List<Double>> vectors = embedWithRetry(batchTexts);

            if (vectors.size() != batchTexts.size()) {
                throw new IllegalStateException("返回向量数量和输入文本数量不一致: input="
                        + batchTexts.size() + ", output=" + vectors.size());
            }

            for (int j = 0; j < vectors.size(); j++) {
                int rowIndex = rowIndexesToEmbed.get(start + j);
                List<String> row = table.rows.get(rowIndex);

                String denseJson = vectorToCompactJson(vectors.get(j));
                row.set(denseIndex, denseJson);

                // 稀疏向量由 Milvus 自动生成，因此这里强制留空。
                if (sparseIndex >= 0) {
                    row.set(sparseIndex, "");
                }

                System.out.println("[OK] row=" + (rowIndex + 2)
                        + ", id=" + valueOf(row, table.headerIndex("id"))
                        + ", dim=" + vectors.get(j).size());
            }

            // 每个 batch 写一次，防止中途失败后全部丢失。
            writeCsv(output, table);
        }

        writeCsv(output, table);
        System.out.println("完成，已输出: " + output.toAbsolutePath());
    }

    // ===========================
    // 3. 调用 BGE-M3 embedding API
    // ===========================

    private List<List<Double>> embedWithRetry(List<String> texts) throws Exception {
        Exception last = null;
        for (int attempt = 1; attempt <= MAX_RETRY; attempt++) {
            try {
                return embed(texts);
            } catch (Exception e) {
                last = e;
                System.out.println("[WARN] embedding 请求失败，第 " + attempt + "/" + MAX_RETRY + " 次: " + e.getMessage());
                if (attempt < MAX_RETRY) {
                    TimeUnit.MILLISECONDS.sleep(RETRY_SLEEP_MS * attempt);
                }
            }
        }
        throw last;
    }

    private List<List<Double>> embed(List<String> texts) throws Exception {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", MODEL);
        body.put("input", texts);

        String requestJson = OBJECT_MAPPER.writeValueAsString(body);

        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(URI.create(endpoint()))
                .timeout(Duration.ofSeconds(TIMEOUT_SECONDS))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(requestJson, StandardCharsets.UTF_8));

        if (API_KEY != null && !API_KEY.isBlank()) {
            builder.header("Authorization", "Bearer " + API_KEY);
        }

        HttpResponse<String> response = httpClient.send(builder.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        int status = response.statusCode();
        String responseBody = response.body();

        if (status < 200 || status >= 300) {
            throw new IOException("HTTP " + status + ": " + responseBody);
        }

        return parseEmbeddingResponse(responseBody);
    }

    /**
     * 兼容常见 OpenAI-compatible embedding 返回：
     * {
     *   "data": [
     *     {"index":0, "embedding":[0.1, ...]},
     *     {"index":1, "embedding":[0.2, ...]}
     *   ]
     * }
     *
     * 也兼容部分本地服务：
     * {"embeddings": [[...], [...]]}
     */
    private List<List<Double>> parseEmbeddingResponse(String responseBody) throws Exception {
        JsonNode root = OBJECT_MAPPER.readTree(responseBody);

        if (root.has("data") && root.get("data").isArray()) {
            JsonNode data = root.get("data");
            List<IndexedVector> indexed = new ArrayList<>();

            for (int i = 0; i < data.size(); i++) {
                JsonNode item = data.get(i);
                int index = item.has("index") ? item.get("index").asInt() : i;
                JsonNode embedding = item.get("embedding");
                if (embedding == null || !embedding.isArray()) {
                    throw new IOException("返回 data[" + i + "] 中没有 embedding 数组: " + item);
                }
                indexed.add(new IndexedVector(index, jsonArrayToDoubleList(embedding)));
            }

            indexed.sort((a, b) -> Integer.compare(a.index, b.index));
            List<List<Double>> vectors = new ArrayList<>();
            for (IndexedVector item : indexed) {
                vectors.add(item.vector);
            }
            return vectors;
        }

        if (root.has("embeddings") && root.get("embeddings").isArray()) {
            JsonNode arr = root.get("embeddings");
            List<List<Double>> vectors = new ArrayList<>();
            for (JsonNode item : arr) {
                if (!item.isArray()) {
                    throw new IOException("embeddings 中存在非数组元素: " + item);
                }
                vectors.add(jsonArrayToDoubleList(item));
            }
            return vectors;
        }

        if (root.has("embedding") && root.get("embedding").isArray()) {
            return List.of(jsonArrayToDoubleList(root.get("embedding")));
        }

        throw new IOException("不支持的 embedding API 返回格式: " + responseBody);
    }

    private List<Double> jsonArrayToDoubleList(JsonNode arr) {
        List<Double> vector = new ArrayList<>(arr.size());
        for (JsonNode node : arr) {
            vector.add(node.asDouble());
        }
        return vector;
    }

    private String vectorToCompactJson(List<Double> vector) throws Exception {
        return OBJECT_MAPPER.writeValueAsString(vector);
    }

    private String endpoint() {
        String base = trimTrailingSlash(BASE_URL);
        String path = EMBEDDING_PATH.startsWith("/") ? EMBEDDING_PATH : "/" + EMBEDDING_PATH;
        return base + path;
    }

    // ===========================
    // 4. CSV 读取和写出
    // ===========================

    private CsvTable readCsv(Path input) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(input, CSV_CHARSET)) {
            String headerLine = reader.readLine();
            if (headerLine == null) {
                throw new IOException("CSV 文件为空: " + input);
            }

            headerLine = removeBom(headerLine);
            List<String> header = parseCsvLine(headerLine);
            CsvTable table = new CsvTable(header);

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) {
                    continue;
                }
                List<String> row = parseCsvLine(line);
                normalizeRowLength(row, header.size());
                table.rows.add(row);
            }
            return table;
        }
    }

    private void writeCsv(Path output, CsvTable table) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(output, CSV_CHARSET)) {
            writer.write('\uFEFF'); // UTF-8 BOM，方便 Windows Excel 直接打开不乱码。
            writer.write(toCsvLine(table.header));
            writer.newLine();

            for (List<String> row : table.rows) {
                normalizeRowLength(row, table.header.size());
                writer.write(toCsvLine(row));
                writer.newLine();
            }
        }
    }

    private List<String> parseCsvLine(String line) {
        List<String> values = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if (c == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    sb.append('"');
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (c == ',' && !inQuotes) {
                values.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(c);
            }
        }
        values.add(sb.toString());
        return values;
    }

    private String toCsvLine(List<String> values) {
        List<String> escaped = new ArrayList<>(values.size());
        for (String value : values) {
            escaped.add(escapeCsv(value));
        }
        return String.join(",", escaped);
    }

    private String escapeCsv(String value) {
        if (value == null) return "";
        boolean needQuote = value.contains(",") || value.contains("\n") || value.contains("\r") || value.contains("\"");
        if (!needQuote) {
            return value;
        }
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    private void normalizeRowLength(List<String> row, int expectedSize) {
        while (row.size() < expectedSize) {
            row.add("");
        }
        while (row.size() > expectedSize) {
            String last = row.remove(row.size() - 1);
            row.set(row.size() - 1, row.get(row.size() - 1) + "," + last);
        }
    }

    // ===========================
    // 5. 校验和辅助方法
    // ===========================

    private void checkConfig() {
        if (REQUIRE_API_KEY && (API_KEY == null || API_KEY.isBlank())) {
            throw new IllegalArgumentException("当前 REQUIRE_API_KEY=true，但 API_KEY 为空。请填写 API_KEY，或设置 REQUIRE_API_KEY=false。");
        }
        if (BASE_URL == null || BASE_URL.isBlank()) {
            throw new IllegalArgumentException("BASE_URL 不能为空");
        }
        if (MODEL == null || MODEL.isBlank()) {
            throw new IllegalArgumentException("MODEL 不能为空");
        }
        if (BATCH_SIZE <= 0) {
            throw new IllegalArgumentException("BATCH_SIZE 必须大于 0");
        }
    }

    private void checkRequiredColumns(CsvTable table) {
        table.requireColumn("id");
        table.requireColumn("title");
        table.requireColumn("chunk_id");
        table.requireColumn(CONTENT_COLUMN);
        table.requireColumn(DENSE_VECTOR_COLUMN);
        table.requireColumn(SPARSE_VECTOR_COLUMN);
        table.requireColumn("doc_id");
    }

    private String removeBom(String line) {
        if (line != null && !line.isEmpty() && line.charAt(0) == '\uFEFF') {
            return line.substring(1);
        }
        return line;
    }

    private static String trimTrailingSlash(String value) {
        if (value == null) return "";
        while (value.endsWith("/") && value.length() > 1) {
            value = value.substring(0, value.length() - 1);
        }
        return value;
    }

    private String valueOf(List<String> row, int index) {
        if (index < 0 || index >= row.size()) return "";
        return Objects.toString(row.get(index), "");
    }

    private record IndexedVector(int index, List<Double> vector) {
    }

    private static class CsvTable {
        private final List<String> header;
        private final List<List<String>> rows = new ArrayList<>();
        private final Map<String, Integer> headerIndex = new LinkedHashMap<>();

        private CsvTable(List<String> header) {
            this.header = header;
            for (int i = 0; i < header.size(); i++) {
                headerIndex.put(header.get(i), i);
            }
        }

        private int headerIndex(String column) {
            return headerIndex.getOrDefault(column, -1);
        }

        private void requireColumn(String column) {
            if (!headerIndex.containsKey(column)) {
                throw new IllegalArgumentException("CSV 缺少必要字段: " + column + ", 当前字段: " + header);
            }
        }
    }
}
