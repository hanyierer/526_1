package com.example.gamerag.model;

import java.util.ArrayList;
import java.util.List;

public class RetrievalPlan {
    private boolean denseVector;
    private boolean sparseVector;
    private List<String> searchQueries = new ArrayList<>();
    private String filterExpression;

    public boolean isDenseVector() { return denseVector; }
    public void setDenseVector(boolean denseVector) { this.denseVector = denseVector; }
    public boolean isSparseVector() { return sparseVector; }
    public void setSparseVector(boolean sparseVector) { this.sparseVector = sparseVector; }
    public List<String> getSearchQueries() { return searchQueries; }
    public void setSearchQueries(List<String> searchQueries) { this.searchQueries = searchQueries == null ? new ArrayList<>() : searchQueries; }
    public String getFilterExpression() { return filterExpression; }
    public void setFilterExpression(String filterExpression) { this.filterExpression = filterExpression; }
}
