package com.example.gamerag.service;

import com.example.gamerag.model.RecallChannel;
import com.example.gamerag.model.SearchHit;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class RrfFusionServiceTest {
    @Test
    void fuseShouldDeduplicateDenseAndSparseResults() {
        RrfFusionService service = new RrfFusionService();
        SearchHit aDense = hit("001", 1, RecallChannel.DENSE_VECTOR);
        SearchHit bDense = hit("002", 2, RecallChannel.DENSE_VECTOR);
        SearchHit aSparse = hit("001", 1, RecallChannel.SPARSE_VECTOR);
        SearchHit cSparse = hit("003", 2, RecallChannel.SPARSE_VECTOR);

        List<SearchHit> fused = service.fuse(List.of(List.of(aDense, bDense), List.of(aSparse, cSparse)), 60, 10);

        assertThat(fused).hasSize(3);
        assertThat(fused.get(0).getId()).isEqualTo("001");
        assertThat(fused.get(0).getScore()).isGreaterThan(fused.get(1).getScore());
    }

    private SearchHit hit(String id, int rank, RecallChannel channel) {
        SearchHit h = new SearchHit(id, "title" + id, "content" + id, 1.0 / rank, channel);
        h.setRank(rank);
        return h;
    }
}
