package com.example.gamerag.model;

public enum RecallChannel {
    DENSE_VECTOR,
    SPARSE_VECTOR
}
