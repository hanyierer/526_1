package com.example.gamerag.service;

import com.example.gamerag.config.RagProperties;
import com.example.gamerag.model.QueryRewriteResult;
import com.example.gamerag.util.JsonExtractUtils;
import com.example.gamerag.util.TextUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class QueryRewriteService {
    private static final Logger log = LoggerFactory.getLogger(QueryRewriteService.class);
    private final RagProperties properties;
    private final DoubaoClient doubaoClient;
    private final ObjectMapper objectMapper;

    public QueryRewriteService(RagProperties properties, DoubaoClient doubaoClient, ObjectMapper objectMapper) {
        this.properties = properties;
        this.doubaoClient = doubaoClient;
        this.objectMapper = objectMapper;
    }

    public QueryRewriteResult rewrite(String rawQuery) {
        if (!properties.getQueryRewrite().isEnabled()) {
            return fallback(rawQuery);
        }
        try {
            String system = "你是王者荣耀知识库 RAG 的查询改写器，只输出 JSON，不要解释。";
            String user = """
                    请把玩家问题改写为适合向量检索的中文查询，并给出最多 %d 个语义相近的扩展查询。
                    只输出严格 JSON：
                    {"rewrittenQuery":"...","expandedQueries":["...","..."]}

                    要求：
                    1. 不要输出关键词字段。
                    2. 不要输出 filters、gameId、intent、strategy。
                    3. 不要编造游戏事实，只做检索表达改写。
                    4. 如果问题中有英雄名、技能名、装备名、地图资源名，请保留在 rewrittenQuery 中。

                    玩家问题：%s
                    """.formatted(properties.getQueryRewrite().getMaxExpandedQueries(), rawQuery);
            String content = doubaoClient.chat(system, user);
            JsonNode json = objectMapper.readTree(JsonExtractUtils.extractFirstJsonObject(content));

            QueryRewriteResult result = new QueryRewriteResult();
            result.setOriginalQuery(rawQuery);
            result.setRewrittenQuery(json.path("rewrittenQuery").asText(rawQuery));
            result.setExpandedQueries(TextUtils.distinctNonBlank(readStringList(json.path("expandedQueries")),
                    properties.getQueryRewrite().getMaxExpandedQueries()));
            return result;
        } catch (Exception e) {
            log.warn("Query rewrite failed, fallback to raw query: {}", e.getMessage());
            if (properties.getQueryRewrite().isFallbackToRawQuery()) {
                return fallback(rawQuery);
            }
            throw new IllegalStateException("Query rewrite failed and fallback is disabled", e);
        }
    }

    private QueryRewriteResult fallback(String rawQuery) {
        QueryRewriteResult result = new QueryRewriteResult();
        result.setOriginalQuery(rawQuery);
        result.setRewrittenQuery(rawQuery);
        result.setExpandedQueries(List.of(rawQuery));
        return result;
    }

    private List<String> readStringList(JsonNode node) {
        List<String> list = new ArrayList<>();
        if (node != null && node.isArray()) {
            for (JsonNode item : node) {
                String value = item.asText("");
                if (!value.isBlank()) list.add(value);
            }
        }
        return list;
    }
}
