package com.example.gamerag.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class RagQueryRequest {
    @NotBlank(message = "query 不能为空")
    @Size(max = 2000, message = "query 过长")
    private String query;
    private Integer topK;
    private Boolean bypassCache = false;
    private Boolean debug = false;

    public String getQuery() { return query; }
    public void setQuery(String query) { this.query = query; }
    public Integer getTopK() { return topK; }
    public void setTopK(Integer topK) { this.topK = topK; }
    public Boolean getBypassCache() { return bypassCache; }
    public void setBypassCache(Boolean bypassCache) { this.bypassCache = bypassCache; }
    public Boolean getDebug() { return debug; }
    public void setDebug(Boolean debug) { this.debug = debug; }
}
