package com.example.gamerag.model;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public class SearchHit {
    private String id;
    private String title;
    private String chunkId;
    private String content;
    private String docId;
    private double score;
    private int rank;
    private RecallChannel channel;
    private Map<String, Object> metadata = new LinkedHashMap<>();

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getChunkId() { return chunkId; }
    public void setChunkId(String chunkId) { this.chunkId = chunkId; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public String getDocId() { return docId; }
    public void setDocId(String docId) { this.docId = docId; }
    public double getScore() { return score; }
    public void setScore(double score) { this.score = score; }
    public int getRank() { return rank; }
    public void setRank(int rank) { this.rank = rank; }
    public RecallChannel getChannel() { return channel; }
    public void setChannel(RecallChannel channel) { this.channel = channel; }
    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata == null ? new LinkedHashMap<>() : metadata; }

    public SearchHit copy() {
        SearchHit hit = new SearchHit();
        hit.setId(id);
        hit.setTitle(title);
        hit.setChunkId(chunkId);
        hit.setContent(content);
        hit.setDocId(docId);
        hit.setScore(score);
        hit.setRank(rank);
        hit.setChannel(channel);
        hit.setMetadata(new LinkedHashMap<>(metadata));
        return hit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SearchHit searchHit)) return false;
        return Objects.equals(id, searchHit.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
