package com.example.gamerag.service;

import com.example.gamerag.config.RagProperties;
import com.example.gamerag.exception.RagException;
import com.example.gamerag.model.QueryRewriteResult;
import com.example.gamerag.model.RecallChannel;
import com.example.gamerag.model.SearchHit;
import com.example.gamerag.util.TextUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class MilvusVectorRetrievalService {
    private static final Logger log = LoggerFactory.getLogger(MilvusVectorRetrievalService.class);

    private final RagProperties properties;
    private final BgeEmbeddingClient embeddingClient;
    private final WebClient webClient;
    private final ObjectMapper objectMapper;

    public MilvusVectorRetrievalService(RagProperties properties,
                                        BgeEmbeddingClient embeddingClient,
                                        WebClient.Builder builder,
                                        ObjectMapper objectMapper) {
        this.properties = properties;
        this.embeddingClient = embeddingClient;
        this.objectMapper = objectMapper;
        this.webClient = builder.clone()
                .baseUrl(properties.getMilvus().getEndpoint())
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();
    }

    public List<List<SearchHit>> recall(QueryRewriteResult rewriteResult) {
        List<String> queries = buildSearchQueries(rewriteResult);
        List<List<SearchHit>> rankedLists = new ArrayList<>();

        for (String query : queries) {
            if (query == null || query.isBlank()) continue;
            if (properties.getMilvus().isDenseSearchEnabled()) {
                rankedLists.add(denseVectorSearch(query));
            }
            if (properties.getMilvus().isSparseSearchEnabled()) {
                rankedLists.add(sparseVectorSearch(query));
            }
        }
        return rankedLists;
    }

    private List<String> buildSearchQueries(QueryRewriteResult rewriteResult) {
        List<String> queries = new ArrayList<>();
        if (rewriteResult != null) {
            queries.add(rewriteResult.getRewrittenQuery());
            queries.addAll(rewriteResult.getExpandedQueries());
            queries.add(rewriteResult.getOriginalQuery());
        }
        return TextUtils.distinctNonBlank(queries, properties.getQueryRewrite().getMaxExpandedQueries() + 2);
    }

    private List<SearchHit> denseVectorSearch(String query) {
        try {
            List<Float> vector = embeddingClient.embed(query);
            Map<String, Object> body = baseSearchBody(
                    properties.getMilvus().getDenseVectorField(),
                    properties.getMilvus().getDenseTopK()
            );
            body.put("data", List.of(vector));
            return postSearch(body, RecallChannel.DENSE_VECTOR);
        } catch (Exception e) {
            log.warn("dense vector search failed for query='{}': {}", query, e.getMessage());
            return List.of();
        }
    }

    private List<SearchHit> sparseVectorSearch(String query) {
        try {
            String sparseField = properties.getMilvus().getSparseVectorField();
            if (sparseField == null || sparseField.isBlank()) return List.of();

            Map<String, Object> body = baseSearchBody(sparseField, properties.getMilvus().getSparseTopK());
            // 当前 schema 使用 content -> Milvus BM25 Function -> content_sparse_vector。
            // 因此搜索时直接传原始文本 query，由 Milvus 将 query 转为 sparse query vector。
            body.put("data", List.of(query));

            // BM25 sparse search 通常不需要 dense ANN search params。
            body.remove("searchParams");
            return postSearch(body, RecallChannel.SPARSE_VECTOR);
        } catch (Exception e) {
            log.warn("sparse vector search failed for query='{}': {}", query, e.getMessage());
            return List.of();
        }
    }

    private Map<String, Object> baseSearchBody(String annsField, int limit) {
        Map<String, Object> body = new LinkedHashMap<>();
        putDb(body);
        body.put("collectionName", properties.getMilvus().getCollection());
        body.put("annsField", annsField);
        body.put("limit", limit);
        body.put("outputFields", properties.getMilvus().getOutputFields());
        body.put("consistencyLevel", properties.getMilvus().getConsistencyLevel());
        Map<String, Object> searchParams = new LinkedHashMap<>();
        searchParams.put("params", Map.of("nprobe", 10));
        body.put("searchParams", searchParams);
        return body;
    }

    private void putDb(Map<String, Object> body) {
        String db = properties.getMilvus().getDatabase();
        if (db != null && !db.isBlank() && !"default".equalsIgnoreCase(db)) {
            body.put("dbName", db);
        }
    }

    private List<SearchHit> postSearch(Map<String, Object> body, RecallChannel channel) {
        JsonNode root = postJson("/v2/vectordb/entities/search", body);
        return parseHits(root, channel);
    }

    private JsonNode postJson(String path, Map<String, Object> body) {
        try {
            String response = webClient.post()
                    .uri(path)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + properties.getMilvus().getToken())
                    .bodyValue(body)
                    .retrieve()
                    .onStatus(status -> status.is4xxClientError() || status.is5xxServerError(), resp ->
                            resp.bodyToMono(String.class).defaultIfEmpty("")
                                    .flatMap(err -> Mono.error(new RagException("Milvus REST 调用失败: HTTP " + resp.statusCode() + " " + err))))
                    .bodyToMono(String.class)
                    .block(Duration.ofSeconds(30));
            return objectMapper.readTree(response);
        } catch (RagException e) {
            throw e;
        } catch (Exception e) {
            throw new RagException("Milvus REST 调用异常: " + e.getMessage(), e);
        }
    }

    private List<SearchHit> parseHits(JsonNode root, RecallChannel channel) {
        List<SearchHit> hits = new ArrayList<>();
        JsonNode data = root.path("data");
        if (!data.isArray()) return hits;
        int[] rank = new int[]{1};
        for (JsonNode node : data) {
            if (node.isArray()) {
                for (JsonNode item : node) parseOneHit(item, channel, rank[0]++).ifPresent(hits::add);
            } else {
                parseOneHit(node, channel, rank[0]++).ifPresent(hits::add);
            }
        }
        return hits;
    }

    private java.util.Optional<SearchHit> parseOneHit(JsonNode node, RecallChannel channel, int rank) {
        JsonNode entity = node.path("entity").isMissingNode() ? node : node.path("entity");
        String id = readText(entity, properties.getMilvus().getPrimaryKeyField());
        if (id == null || id.isBlank()) id = readText(node, properties.getMilvus().getPrimaryKeyField());
        if (id == null || id.isBlank()) id = readText(node, "id");

        String content = readText(entity, properties.getMilvus().getTextField());
        if (id == null || id.isBlank() || content == null || content.isBlank()) {
            return java.util.Optional.empty();
        }

        SearchHit hit = new SearchHit();
        hit.setId(id);
        hit.setTitle(readText(entity, properties.getMilvus().getTitleField()));
        hit.setChunkId(readText(entity, properties.getMilvus().getChunkIdField()));
        hit.setContent(content);
        hit.setDocId(readText(entity, properties.getMilvus().getDocIdField()));
        hit.setScore(readScore(node, rank));
        hit.setRank(rank);
        hit.setChannel(channel);

        Map<String, Object> meta = new LinkedHashMap<>();
        for (String field : properties.getMilvus().getOutputFields()) {
            JsonNode val = entity.path(field);
            if (!val.isMissingNode() && !val.isNull()) meta.put(field, val.isValueNode() ? val.asText() : val.toString());
        }
        meta.put("recall_channel", channel.name());
        hit.setMetadata(meta);
        return java.util.Optional.of(hit);
    }

    private String readText(JsonNode node, String field) {
        if (node == null || field == null || field.isBlank()) return null;
        JsonNode value = node.path(field);
        if (value.isMissingNode() || value.isNull()) return null;
        return value.isValueNode() ? value.asText() : value.toString();
    }

    private double readScore(JsonNode node, int rank) {
        if (node.has("score")) return node.path("score").asDouble();
        if (node.has("distance")) return node.path("distance").asDouble();
        return 1.0 / Math.max(1, rank);
    }
}
