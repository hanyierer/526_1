package com.example.gamerag.dto;

public class ReferenceDto {
    private int index;
    private String id;
    private String title;
    private String docId;
    private String chunkId;
    private double score;
    private String snippet;

    public int getIndex() { return index; }
    public void setIndex(int index) { this.index = index; }
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDocId() { return docId; }
    public void setDocId(String docId) { this.docId = docId; }
    public String getChunkId() { return chunkId; }
    public void setChunkId(String chunkId) { this.chunkId = chunkId; }
    public double getScore() { return score; }
    public void setScore(double score) { this.score = score; }
    public String getSnippet() { return snippet; }
    public void setSnippet(String snippet) { this.snippet = snippet; }
}
