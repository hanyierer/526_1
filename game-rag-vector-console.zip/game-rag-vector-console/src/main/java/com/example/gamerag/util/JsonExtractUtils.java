package com.example.gamerag.util;

public final class JsonExtractUtils {
    private JsonExtractUtils() {}

    public static String extractFirstJsonObject(String text) {
        if (text == null) return "{}";
        int start = text.indexOf('{');
        int end = text.lastIndexOf('}');
        if (start >= 0 && end > start) return text.substring(start, end + 1);
        return "{}";
    }
}
