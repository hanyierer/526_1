package com.example.gamerag.model;

import java.util.ArrayList;
import java.util.List;

public class QueryRewriteResult {
    private String originalQuery;
    private String rewrittenQuery;
    private List<String> expandedQueries = new ArrayList<>();

    public String getOriginalQuery() { return originalQuery; }
    public void setOriginalQuery(String originalQuery) { this.originalQuery = originalQuery; }
    public String getRewrittenQuery() { return rewrittenQuery; }
    public void setRewrittenQuery(String rewrittenQuery) { this.rewrittenQuery = rewrittenQuery; }
    public List<String> getExpandedQueries() { return expandedQueries; }
    public void setExpandedQueries(List<String> expandedQueries) { this.expandedQueries = expandedQueries == null ? new ArrayList<>() : expandedQueries; }
}
