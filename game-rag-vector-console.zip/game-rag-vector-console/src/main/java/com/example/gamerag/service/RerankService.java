package com.example.gamerag.service;

import com.example.gamerag.config.RagProperties;
import com.example.gamerag.model.QueryRewriteResult;
import com.example.gamerag.model.SearchHit;
import com.example.gamerag.util.TextUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class RerankService {
    private static final Logger log = LoggerFactory.getLogger(RerankService.class);
    private final RagProperties properties;
    private final BgeRerankerClient bgeRerankerClient;

    public RerankService(RagProperties properties, BgeRerankerClient bgeRerankerClient) {
        this.properties = properties;
        this.bgeRerankerClient = bgeRerankerClient;
    }

    public List<SearchHit> rerank(QueryRewriteResult rewrite, List<SearchHit> candidates, int topK) {
        if (candidates == null || candidates.isEmpty()) return List.of();
        List<SearchHit> limited = candidates.size() > properties.getRetrieval().getRerankCandidateK()
                ? new ArrayList<>(candidates.subList(0, properties.getRetrieval().getRerankCandidateK()))
                : new ArrayList<>(candidates);

        List<SearchHit> reranked;
        if (properties.getReranker().isEnabled()) {
            try {
                reranked = rerankByBge(rewrite, limited);
            } catch (Exception e) {
                if (!properties.getReranker().isFallbackToRrf()) throw e;
                log.warn("BGE rerank failed, fallback to RRF order: {}", e.getMessage());
                reranked = limited;
            }
        } else {
            reranked = limited;
        }
        return reranked.size() > topK ? reranked.subList(0, topK) : reranked;
    }

    private List<SearchHit> rerankByBge(QueryRewriteResult rewrite, List<SearchHit> candidates) {
        String query = chooseRerankQuery(rewrite);
        List<String> documents = candidates.stream().map(this::formatDocumentForRerank).toList();
        List<BgeRerankerClient.RerankScore> scores = bgeRerankerClient.rerank(query, documents, candidates.size());

        Map<Integer, Double> scoreByIndex = new HashMap<>();
        for (BgeRerankerClient.RerankScore score : scores) scoreByIndex.put(score.index(), score.score());

        double minRecall = candidates.stream().mapToDouble(SearchHit::getScore).min().orElse(0.0);
        double maxRecall = candidates.stream().mapToDouble(SearchHit::getScore).max().orElse(1.0);
        double rerankWeight = clamp(properties.getReranker().getRerankWeight(), 0.0, 1.0);

        List<SearchHit> reranked = new ArrayList<>();
        for (int i = 0; i < candidates.size(); i++) {
            SearchHit hit = candidates.get(i);
            Double rawScore = scoreByIndex.get(i);
            double recall = normalizeRecallScore(hit.getScore(), minRecall, maxRecall);
            if (rawScore == null) {
                hit.setScore((1.0 - rerankWeight) * recall);
                hit.getMetadata().put("bge_rerank_missing", true);
            } else {
                double normalizedRerank = normalizeRerankScore(rawScore);
                hit.getMetadata().put("bge_rerank_raw_score", rawScore);
                hit.getMetadata().put("bge_rerank_normalized_score", normalizedRerank);
                hit.getMetadata().put("rrf_score_before_rerank", hit.getScore());
                hit.setScore(rerankWeight * normalizedRerank + (1.0 - rerankWeight) * recall);
            }
            hit.getMetadata().put("rerank_model", properties.getReranker().getModel());
            reranked.add(hit);
        }

        reranked.sort(Comparator.comparingDouble(SearchHit::getScore).reversed());
        for (int i = 0; i < reranked.size(); i++) reranked.get(i).setRank(i + 1);
        return reranked;
    }

    private String chooseRerankQuery(QueryRewriteResult rewrite) {
        if (rewrite == null) return "";
        if (rewrite.getRewrittenQuery() != null && !rewrite.getRewrittenQuery().isBlank()) return rewrite.getRewrittenQuery();
        return rewrite.getOriginalQuery() == null ? "" : rewrite.getOriginalQuery();
    }

    private String formatDocumentForRerank(SearchHit hit) {
        String title = hit.getTitle() == null ? "" : hit.getTitle();
        String content = hit.getContent() == null ? "" : hit.getContent();
        String document = title.isBlank() ? content : "标题：" + title + "\n内容：" + content;
        return TextUtils.truncate(document, Math.max(200, properties.getReranker().getMaxDocumentChars()));
    }

    private double normalizeRerankScore(double rawScore) {
        if (rawScore >= 0.0 && rawScore <= 1.0) return rawScore;
        return 1.0 / (1.0 + Math.exp(-rawScore));
    }

    private double normalizeRecallScore(double score, double min, double max) {
        if (Math.abs(max - min) < 1e-12) return 0.5;
        return (score - min) / (max - min);
    }

    private double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }
}
