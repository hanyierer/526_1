package com.example.gamerag.service;

import com.example.gamerag.config.RagProperties;
import com.example.gamerag.model.QueryRewriteResult;
import com.example.gamerag.model.SearchHit;
import com.example.gamerag.util.TextUtils;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PromptBuilder {
    private final RagProperties properties;

    public PromptBuilder(RagProperties properties) {
        this.properties = properties;
    }

    public String buildUserPrompt(String rawQuery, QueryRewriteResult rewrite, List<SearchHit> docs) {
        StringBuilder ctx = new StringBuilder();
        int maxContext = properties.getPrompt().getMaxContextChars();
        int maxDoc = properties.getPrompt().getMaxDocChars();

        for (int i = 0; i < docs.size(); i++) {
            SearchHit doc = docs.get(i);
            String block = """
                    [%d]
                    ID：%s
                    标题：%s
                    doc_id：%s
                    chunk_id：%s
                    内容：%s

                    """.formatted(
                    i + 1,
                    safe(doc.getId()),
                    safe(doc.getTitle()),
                    safe(doc.getDocId()),
                    safe(doc.getChunkId()),
                    TextUtils.truncate(safe(doc.getContent()), maxDoc)
            );
            if (ctx.length() + block.length() > maxContext) break;
            ctx.append(block);
        }

        return """
                玩家原始问题：%s
                改写后的检索查询：%s
                扩展查询：%s

                知识库片段：
                %s

                请基于以上片段回答玩家问题。
                输出要求：
                1. 先直接回答结论，再给步骤/条件/注意事项。
                2. 每个关键结论后用 [1]、[2] 标注依据。
                3. 如果片段之间有冲突，请说明可能与版本或来源有关。
                4. 如果证据不足，不要猜测，说明知识库中没有足够信息。
                """.formatted(rawQuery,
                rewrite == null ? rawQuery : rewrite.getRewrittenQuery(),
                rewrite == null ? List.of() : rewrite.getExpandedQueries(),
                ctx);
    }

    private String safe(String value) { return value == null ? "" : value; }
}
