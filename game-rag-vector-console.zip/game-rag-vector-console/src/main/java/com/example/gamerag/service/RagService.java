package com.example.gamerag.service;

import com.example.gamerag.config.RagProperties;
import com.example.gamerag.dto.RagQueryRequest;
import com.example.gamerag.dto.RagQueryResponse;
import com.example.gamerag.dto.ReferenceDto;
import com.example.gamerag.model.QueryRewriteResult;
import com.example.gamerag.model.SearchHit;
import com.example.gamerag.util.TextUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class RagService {
    private final RagProperties properties;
    private final RagCacheService cacheService;
    private final QueryRewriteService queryRewriteService;
    private final MilvusVectorRetrievalService retrievalService;
    private final RrfFusionService rrfFusionService;
    private final RerankService rerankService;
    private final PromptBuilder promptBuilder;
    private final DoubaoClient doubaoClient;

    public RagService(RagProperties properties,
                      RagCacheService cacheService,
                      QueryRewriteService queryRewriteService,
                      MilvusVectorRetrievalService retrievalService,
                      RrfFusionService rrfFusionService,
                      RerankService rerankService,
                      PromptBuilder promptBuilder,
                      DoubaoClient doubaoClient) {
        this.properties = properties;
        this.cacheService = cacheService;
        this.queryRewriteService = queryRewriteService;
        this.retrievalService = retrievalService;
        this.rrfFusionService = rrfFusionService;
        this.rerankService = rerankService;
        this.promptBuilder = promptBuilder;
        this.doubaoClient = doubaoClient;
    }

    public RagQueryResponse query(RagQueryRequest request) {
        return cacheService.get(request).orElseGet(() -> execute(request));
    }

    public void clearCache() {
        cacheService.clear();
    }

    private RagQueryResponse execute(RagQueryRequest request) {
        long start = System.currentTimeMillis();
        QueryRewriteResult rewrite = queryRewriteService.rewrite(request.getQuery());
        List<List<SearchHit>> recallLists = retrievalService.recall(rewrite);
        int rawHitCount = recallLists.stream().mapToInt(List::size).sum();
        List<SearchHit> fused = rrfFusionService.fuse(recallLists, properties.getRetrieval().getRrfK(), properties.getRetrieval().getFusedTopK());

        int finalTopK = request.getTopK() != null && request.getTopK() > 0
                ? Math.min(request.getTopK(), 20)
                : properties.getRetrieval().getFinalTopK();
        List<SearchHit> topDocs = rerankService.rerank(rewrite, fused, finalTopK).stream()
                .filter(h -> h.getScore() >= properties.getRetrieval().getMinScore())
                .toList();

        String answer;
        if (topDocs.isEmpty()) {
            answer = "知识库中没有足够信息回答这个问题。请换一个更具体的问题，例如英雄名、技能名、装备名或地图资源名。";
        } else {
            String userPrompt = promptBuilder.buildUserPrompt(request.getQuery(), rewrite, topDocs);
            answer = doubaoClient.chat(properties.getPrompt().getSystemMessage(), userPrompt);
        }

        RagQueryResponse response = new RagQueryResponse();
        response.setQuery(request.getQuery());
        response.setAnswer(answer);
        response.setCacheHit(false);
        response.setQueryRewrite(rewrite);
        response.setReferences(toReferences(topDocs));

        if (Boolean.TRUE.equals(request.getDebug())) {
            Map<String, Object> debug = new LinkedHashMap<>();
            debug.put("embeddingModel", properties.getEmbedding().getModel());
            debug.put("rerankerModel", properties.getReranker().isEnabled() ? properties.getReranker().getModel() : "disabled");
            debug.put("denseSearchEnabled", properties.getMilvus().isDenseSearchEnabled());
            debug.put("sparseSearchEnabled", properties.getMilvus().isSparseSearchEnabled());
            debug.put("denseVectorField", properties.getMilvus().getDenseVectorField());
            debug.put("sparseVectorField", properties.getMilvus().getSparseVectorField());
            debug.put("rawHitCount", rawHitCount);
            debug.put("fusedHitCount", fused.size());
            debug.put("finalDocCount", topDocs.size());
            debug.put("latencyMs", System.currentTimeMillis() - start);
            debug.put("cacheSize", cacheService.estimatedSize());
            response.setDebug(debug);
        }

        cacheService.put(request, response);
        return response;
    }

    private List<ReferenceDto> toReferences(List<SearchHit> docs) {
        List<ReferenceDto> refs = new ArrayList<>();
        for (int i = 0; i < docs.size(); i++) {
            SearchHit doc = docs.get(i);
            ReferenceDto ref = new ReferenceDto();
            ref.setIndex(i + 1);
            ref.setId(doc.getId());
            ref.setTitle(doc.getTitle());
            ref.setDocId(doc.getDocId());
            ref.setChunkId(doc.getChunkId());
            ref.setScore(doc.getScore());
            ref.setSnippet(TextUtils.truncate(doc.getContent(), 240));
            refs.add(ref);
        }
        return refs;
    }
}
