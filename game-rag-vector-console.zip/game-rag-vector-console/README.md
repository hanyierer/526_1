# game-rag-vector-console

这是一个按当前 Milvus schema 精简后的控制台版游戏知识库 RAG 项目。

## 当前 Milvus collection 字段

```text
id
title
chunk_id
content
content_dense_vector
content_sparse_vector
doc_id
```

注意：字段名请使用 `chunk_id`，不要使用 `chunk-id`。Java、Milvus filter、JSON 字段和配置中使用下划线更稳定。

## 已删除/简化的内容

相比之前的项目，本版本删除了：

```text
1. 关键词检索 keyword query / TEXT_MATCH
2. filters
3. gameId / game_id 过滤
4. RetrievalRouter
5. IntentType / RetrievalStrategy
6. QueryAnalysis 里的 keywords、entities、filters、intent、strategy
7. source/url/doc_type/version 等多余返回字段
8. Web Controller，默认只做控制台输入输出
```

只保留两种召回：

```text
1. Dense vector search:
   query -> BGE-M3 embedding -> content_dense_vector

2. Sparse vector search:
   query raw text -> Milvus BM25 Function -> content_sparse_vector
```

后续流程：

```text
两路向量召回 -> RRF 融合去重 -> bge-reranker-v2-m3 精排 -> 豆包生成答案 -> 控制台输出
```

## 需要配置什么

配置文件：

```text
src/main/resources/application.yml
```

最关键配置：

```yaml
rag:
  doubao:
    api-key: ${DOUBAO_API_KEY:}
    chat-model: ${DOUBAO_CHAT_MODEL:ep-your-doubao-chat-endpoint}

  embedding:
    api-key: ${BGE_API_KEY:}
    base-url: ${BGE_BASE_URL:https://api.siliconflow.cn/v1}
    model: ${BGE_EMBEDDING_MODEL:BAAI/bge-m3}

  reranker:
    api-key: ${BGE_RERANK_API_KEY:${BGE_API_KEY:}}
    model: ${BGE_RERANK_MODEL:BAAI/bge-reranker-v2-m3}

  milvus:
    endpoint: ${MILVUS_ENDPOINT:http://localhost:19530}
    token: ${MILVUS_TOKEN:root:Milvus}
    collection: ${MILVUS_COLLECTION:wzry_knowledge}
    primary-key-field: id
    title-field: title
    chunk-id-field: chunk_id
    text-field: content
    dense-vector-field: content_dense_vector
    sparse-vector-field: content_sparse_vector
    doc-id-field: doc_id
```

## 环境变量示例

Windows PowerShell：

```powershell
$env:DOUBAO_API_KEY="你的豆包APIKey"
$env:DOUBAO_CHAT_MODEL="你的豆包接入点ID"

$env:BGE_API_KEY="你的BGE API Key"
$env:BGE_BASE_URL="https://api.siliconflow.cn/v1"
$env:BGE_EMBEDDING_MODEL="BAAI/bge-m3"
$env:BGE_RERANK_MODEL="BAAI/bge-reranker-v2-m3"

$env:MILVUS_ENDPOINT="http://localhost:19530"
$env:MILVUS_TOKEN="root:Milvus"
$env:MILVUS_COLLECTION="wzry_knowledge"
```

本地无鉴权 BGE 服务：

```powershell
$env:BGE_REQUIRE_API_KEY="false"
$env:BGE_RERANK_REQUIRE_API_KEY="false"
$env:BGE_BASE_URL="http://127.0.0.1:8000/v1"
```

## 运行

```bash
mvn clean package -DskipTests
java -Dfile.encoding=UTF-8 -jar target/game-rag-vector-console-1.0.0.jar
```

Windows CMD 先执行：

```bat
chcp 65001
```

再执行：

```bat
java -Dfile.encoding=UTF-8 -jar target\game-rag-vector-console-1.0.0.jar
```

## 控制台命令

启动后会进入：

```text
RAG>
```

可以直接输入：

```text
孙尚香一技能怎么用？
```

命令：

```text
:config        查看配置
:topk 6        设置引用片段数量
:debug on      开启 debug
:debug off     关闭 debug
:cache clear   清空缓存
exit / quit    退出
```

## 第一次测试建议

如果 sparse 检索还没配置好，先在 `application.yml` 里关掉：

```yaml
rag:
  milvus:
    dense-search-enabled: true
    sparse-search-enabled: false
```

先确认 dense 检索能跑通，再打开：

```yaml
sparse-search-enabled: true
```

## 文件对应说明

```text
RagProperties.java                  全部配置项
ConsoleRagRunner.java               控制台输入输出
QueryRewriteService.java            可选 query 改写，只输出 rewrittenQuery/expandedQueries
MilvusVectorRetrievalService.java   只做 dense/sparse 两路向量检索
RrfFusionService.java               两路检索结果 RRF 融合去重
RerankService.java                  bge-reranker-v2-m3 精排
RagService.java                     RAG 主流程编排
PromptBuilder.java                  prompt 上下文组装
```
