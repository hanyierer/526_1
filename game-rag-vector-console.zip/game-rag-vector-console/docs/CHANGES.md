# 关键修改点

## 删除的模块

- 删除 RetrievalRouter，不再根据 intent/strategy 路由。
- 删除 keyword 检索，不再使用 TEXT_MATCH。
- 删除 filters，不再支持请求侧过滤。
- 删除 gameId/game_id 过滤。
- 删除 source/url/doc_type/version 字段。
- 删除 IntentType、RetrievalStrategy。
- QueryAnalysis 改为 QueryRewriteResult，只保留 originalQuery、rewrittenQuery、expandedQueries。

## 新的 Milvus 字段映射

```yaml
primary-key-field: id
title-field: title
chunk-id-field: chunk_id
text-field: content
dense-vector-field: content_dense_vector
sparse-vector-field: content_sparse_vector
doc-id-field: doc_id
```

## 只保留两路向量检索

- dense vector: BGE-M3 生成 query vector，搜索 `content_dense_vector`。
- sparse vector: query 文本直接传给 Milvus，搜索 `content_sparse_vector`。

## 控制台模式

默认配置：

```yaml
spring:
  main:
    web-application-type: none

rag:
  console:
    enabled: true
```
